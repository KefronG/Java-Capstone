package sample;

public enum PokemonType {
    NORMAL,
    GRASS,
    WATER,
    FIRE,
    ELECTRIC,
    ROCK,
    BUG

}
