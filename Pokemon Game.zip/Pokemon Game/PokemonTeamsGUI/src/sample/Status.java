package sample;

public enum Status {
    NORMAL,
    ASLEEP,
    PARALYZED,
    PROTECTED,
    POISONED,
    BURNED
}
